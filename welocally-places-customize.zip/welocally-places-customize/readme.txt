=== Welocally Places Customize Add On ===
Contributors: claytantor 
Tags: hyperlocal, geocoding, places, maps
Requires at least: welocally-place 1.0.16 or greater
Stable tag: trunk
License: Welocally Places Add On License

