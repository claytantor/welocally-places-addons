<?php
if ( !class_exists( 'WelocallyPlacesCustomize' )) {
	
	class WelocallyPlacesCustomize {		
		const VERSION 				= '1.1.18.DEV';
	}
	
	
	global $wlPlacesCustomize;
	$wlPlaces = new WelocallyPlacesCustomize();

}
?>
